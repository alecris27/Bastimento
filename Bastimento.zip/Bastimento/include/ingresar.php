<?php
   
include ("conexion.php");

if (isset($_POST['accion'])){ 
    switch ($_POST['accion']){
        //casos de registros
       
            case 'acceso_user';
            acceso_user();
            break;
		}
	}

    function acceso_user() {
        
        $email=$_POST['email'];
        $password=$_POST['password'];
        session_start();
        $_SESSION['email']=$email;

        $conexion=mysqli_connect("localhost","root","","bastimento");
        $consulta= "SELECT * FROM usuarios WHERE email='$email' AND password='$password' ";
        $resultado=mysqli_query($conexion, $consulta);
        $filas=mysqli_fetch_array($resultado);



        if($filas['rol'] == 1){ //admin
            echo $_SESSION['email']; 
            header('Location: ../Admin/inicio.php');

        }else if($filas['rol'] == 2){//usuario
            header('Location: ../User/inicio.php');
        }
        
        
        else{
            echo '<script language="javascript">alert("Error de autentificacion");
            window.location.href="../index.php"</script>';
            
            session_destroy();

        }

      
    }
?>