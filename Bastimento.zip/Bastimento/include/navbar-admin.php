<style>
  .overlay {
    height: 100%;
    width: 0px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: rgba(255,255,255, 90%);
    overflow-x: hidden;
    transition: 0.5s;
  }

  .overlay-content {
    position: relative;
    top: 10%;
    text-align: center;
    font-size: 10px;
  }

  .overlay a {
    padding: 8px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
  }

  .overlay a:hover, .overlay a:focus {
    color: #f1f1f1;
  }

  .overlay .closebtn {
    position: absolute;
    right: 45px;
  }

  @media screen and (max-height: 450px) {
    .overlay a {
      font-size: 20px
    }
    .overlay .closebtn {
      font-size: 40px;
      top: 15px;
      right: 35px;
    }
  }
</style>

    <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow" style="justify-content: space-between;">
      <div id="myNav" class="overlay">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="overlay-content">
          <a href="index"><img src="../img/UPTA.png" style="width: 80px;"></a>
          <a href="inicio.php">Inicio</a>
          <a href="menu.php">Menú</a>
          <a href="#">Empleados</a>
          <a href="">Inventario</a>
          <a href="">Horario</a>
          <a href="">Ventas</a>
          <a href="">Proveedores</a>
        </div>
      </div>

      <span class="navbar-brand col-sm-3 col-md-2 mr-0" style="font-size: 30px; cursor: pointer; color: white; padding: 0px 10px; font-weight: bold;" onclick="openNav()">&#9776; Bastimento C.A</span>

      <ul class="navbar-nav">
        <li class="nav-item" style="color: white; text-align-last: center;">
          <div class="reloj">
              <div class="tiempo"></div>
            <div class="fecha"></div>
            </div>
        </li>
      </ul>

      <div class="dropdown" style="width: 13%;">
          <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false" style="font-weight: bold;">
            <?php echo $_SESSION['email']; ?>
          </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1" style="">
              <a class="dropdown-item" href="inicio.php">Ir a Inicio</a>
              <a class="dropdown-item" href="#">Ayuda</a>
              <a class="dropdown-item" href="perfil.php">Perfil</a>
              <a class="dropdown-item" href="../respaldo/php/respaldar.php">Respaldar BD</a>
              <hr class="dropdown-divider">
              <a class="dropdown-item" href="../include/cerrar.php" style="color: red;">Cerrar Sesion</a>
            </ul>
      </div>
    </nav>
    <br>

    <script src="../js/datetime.js"></script>
        
    <script src="../js/bootstrap.bundle.min.js"></script>

    <script>
    function openNav() {
      document.getElementById("myNav").style.width = "212px";
    }

    function closeNav() {
      document.getElementById("myNav").style.width = "0%";
    }
    </script>

    