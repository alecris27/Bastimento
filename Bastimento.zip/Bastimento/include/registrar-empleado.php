<?php
include("conexion.php");

if (!empty($_POST['Registrar'])) {
	if (!empty($_POST['nombre_apellido']) and !empty($_POST['cedula']) and !empty($_POST['telefono']) and !empty($_POST['email']) and !empty($_POST['telefono']) and !empty($_POST['password'])) {
		
		$nombre_apellido=$_POST['nombre_apellido'];
		$cedula=$_POST['cedula'];
		$telefono=$_POST['telefono'];
		$email=$_POST['email'];
		$password=$_POST['password'];

		$sql=$conexion->query("INSERT INTO nuevo (nombre_apellido, cedula, telefono, email, password) values ('$nombre_apellido', '$cedula', '$telefono', '$email', '$password')");
		if ($sql==1) {
			echo '<script language="javascript">alert("Registrado Exitosamente!");
            window.location.href="../index.php"</script>';
		}else{	
			echo '<script language="javascript">alert("Error al Registrar Empleado");
            window.location.href="../registrar.php"</script>';
		}

	}else{
		echo '<script language="javascript">alert("Algunos campos estan vacios");
        window.location.href="../registrar.php"</script>';
	}

}

?>