<?php

session_start();

error_reporting(0);

$validar = $_SESSION['email'];

if( $validar == null || $validar = ''){

  header("Location: ../iniciar.php");
  die();
}

?>

<!DOCTYPE html>
<html lang="es">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-sca">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <script src="../js/scrollreveal.min.js"></script>

  <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../css/perfil.css">
  
  <link rel="icon" href="">
  <title>Perfi de <?php echo $_SESSION['email']; ?> | Happy Food (Prototipo)</title>
</head>
<body>

    <?php include("../include/navbar-admin.php");?>
  
    <div class="main">
      <h2 style="color: white;">Perfil:</h2>
        <div class="card">
          <section>
            <img src="../img/icons/avatar.png" style="width: 25%";>
          </section>
            <div class="card-body">
              <table>
                <?php 
                  $email=$_SESSION['email'];
                  include ("../include/conexion.php");
                  $sql = $conexion-> query(" SELECT * FROM usuarios WHERE email ='$email'; ");
                  while ($resultado=$sql->fetch_object()){ 
                ?>
                <tbody>
                  <tr>
                    <td>Nombre: <?=$resultado->nombre_apellido ?> </td>
                  </tr>
                  <tr> 
                    <td>Cedula: <?=$resultado->cedula ?> </td>
                  </tr>
                  <tr>
                    <td>Telefono: <?=$resultado->telefono ?> </td>
                  </tr>
                  <tr>
                    <td>Correo: <?=$resultado->email ?> </td>
                  </tr>
                  <tr>
                    <td>Cargo: Empleado </td>
                  </tr>
                </tbody>
                <?php
                  }
                ?>
              </table>
            </div>
        </div>
    </div>

     <?php include("../include/footer.html");?>
    
    <script>
        window.sr = ScrollReveal();
        sr.reveal('.main', {
        duration: 2000,
        origin: 'top',
        distance: '300px'
        });
    </script>
    

</body>
</html>