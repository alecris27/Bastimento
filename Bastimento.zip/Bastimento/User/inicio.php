<?php

session_start();
error_reporting(0);

$validar = $_SESSION['email'];

if( $validar == null || $validar = ''){

  header("Location: ../index.php");
  die();
  
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--CSS--->
    <link rel="stylesheet" type="text/css" href="../css/main.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min(2).css">
    
    <!---DataTables-->
    <script type="text/javascript" src="../js/jquery.js"></script>

    <script src="../js/tablaespañol.js"></script>

    <link rel="stylesheet" href="../datatables/css/jquery.dataTables.min.css">

    <script type="text/javascript" src="../datatables/js/jquery.dataTables.min.js"></script>
    <!----->

    <!--JS-->
    
    <!----->

    <link rel="icon" href="">
    <title>Inicio</title>
  </head>

  <body>

      <?php include("../include/navbar-user.php")?>

        <main role="main" >
          <div class="chartjs-size-monitor" style="position: absolute; inset: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
            <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
              <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0">
              
              </div>
            </div>
            <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
              <div style="position:absolute;width:200%;height:200%;left:0; top:0">
              </div>
             </div>
          </div>

          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <?php 
                  $email=$_SESSION['email'];
                  include ("../include/conexion.php");
                  $sql = $conexion-> query(" SELECT * FROM usuarios WHERE email='$email'; ");
                  while ($resultado=$sql->fetch_object()){ 
                ?>
            <h1 class="h2">Bienvenido <?=$resultado->nombre_apellido ?></h1>
            <?php
                  }
                ?>
          </div>
          <!---Contenido--->
          <!--Col-1-->
          <div class="container px-4 py-5" id="custom-cards">
            <div class="row row-cols-1 row-cols-lg-3 align-items-stretch g-4 py-5">

              <a class="btn btn-light" href="inventario.php">
                <div class="col" >
                  <div class="card card-cover h-100 overflow-hidden text-bg-dark rounded-4 shadow-lg" style="background-image: url('../img/inventario.jpg'); background-size: 123%;">
                    <div class="d-flex flex-column h-100 p-5 pb-3  text-shadow-1">
                      <h3 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold">Inventario</h3>
                    </div>
                  </div>
                </div>
              </a>

              <a class="btn btn-light" href="productos.php">
                <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-bg-dark rounded-4 shadow-lg" style="background-image: url('../img/productos.jpg'); background-size: 200%;">
                    <div class="d-flex flex-column h-100 p-5 pb-3  text-shadow-1">
                      <h3 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold">Productos</h3>
                      
                    </div>
                  </div>
                </div>
              </a>

              <a class="btn btn-light" href="ventas.php">
                <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-bg-dark rounded-4 shadow-lg" style="background-image: url('../img/ventas.jpeg'); background-size: 155%;">
                    <div class="d-flex flex-column h-100 p-5 pb-3  text-shadow-1">
                      <h3 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold">Ventas</h3>
                      
                    </div>
                  </div>
                </div>
              </a>

              <a class="btn btn-light" href="horario.php">
                <div class="col">
                  <div class="card card-cover h-100 overflow-hidden text-bg-dark rounded-4 shadow-lg" style="background-image: url('../img/horario.jpg'); background-size: 125%;">
                    <div class="d-flex flex-column h-100 p-5 pb-3 text-shadow-1">
                      <h3 class="pt-5 mt-5 mb-4 display-6 lh-1 fw-bold">Horario</h3>
                      
                    </div>
                  </div>
                </div>
              </a>             

            </div>
          </div>

          <!--Tablas-->
          <center><h2>Ventas</h2></center>
          <div class="table-responsive" style="padding: 0px 20px;">
            <table id="example" class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>Nº</th>
                  <th>Producto</th>
                  <th>Cantidad</th>
                  <th>Costo</th>
                  <th>Fecha</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $conexion=mysqli_connect("localhost","root","","bastimento");               
                $SQL="SELECT * FROM ventas";
                $dato = mysqli_query($conexion, $SQL);
                if($dato -> num_rows >0){
                    while($fila=mysqli_fetch_array($dato)){  
                ?>
                <tr>
                  <td><?php echo $fila['id_venta']; ?></td>
                  <td><?php echo $fila['productos']; ?></td>
                  <td><?php echo $fila['cantidad']; ?></td>
                  <td><?php echo $fila['costo']; ?></td>
                  <td><?php echo $fila['fecha_emision']; ?></td>
                </tr>
                <?php
                  }
                }
                ?>  
              </tbody>
              <tfoot>
              </tfoot>
            </table>
          </div>
          <br>
          <hr>

        </main>

    <?php include("../include/footer.html")?>

    <script src="../js/scrollreveal.min.js"></script>

     <script>
        window.sr = ScrollReveal();
        sr.reveal('#custom-cards', {
        duration: 2000,
        origin: 'top',
        distance: '300px'
        });
    </script>

    <script>
        window.sr = ScrollReveal();
        sr.reveal('.table-responsive', {
        duration: 2000,
        origin: 'left',
        distance: '300px'
        });
    </script>
    
</body>
</html>