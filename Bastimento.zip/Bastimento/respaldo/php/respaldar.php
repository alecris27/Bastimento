<?php

session_start();
error_reporting(0);

$validar = $_SESSION['email'];

if( $validar == null || $validar = ''){

    header("Location: ../iniciar.php");
    die();
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

	<link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
	<link rel="icon" href="">
	<title>Respaldar Base de Datos</title>
</head>
<body>
	<?php
		include 'Connet.php';
	?>
	<a href="../../Admin/inicio.php"><<--Regresar a inicio</a>
	<div class="container" style="background: #c5c3c3; border-radius: 3rem; width: 30%; margin: 2% 35%; padding: 20px;">
		<center><a class="btn btn-primary" href="./Backup.php">Realizar copia de seguridad</a></center>
		<form action="./Restore.php" method="POST" style="text-align: center;">
						<br>
						<label>Selecciona un archivo de restauración</label><br>
						<select name="restorePoint" class="form-control">
							<option value="" disabled="" selected="">Selecciona...</option>
						<?php
							$ruta=BACKUP_PATH;
							if(is_dir($ruta)){
							    if($aux=opendir($ruta)){
							        while(($archivo = readdir($aux)) !== false){
							            if($archivo!="."&&$archivo!=".."){
							                $nombrearchivo=str_replace(".sql", "", $archivo);
							                $nombrearchivo=str_replace("-", ":", $nombrearchivo);
							                $ruta_completa=$ruta.$archivo;
							                if(is_dir($ruta_completa)){
							                }else{
							                    echo '<option value="'.$ruta_completa.'">'.$nombrearchivo.'</option>';
							                }
							            }
							        }
							        closedir($aux);
							    }
							}else{
							    echo $ruta." No es ruta válida";
							}
						?>
					</select>
					<br>
					<button type="submit" class="btn btn-success" style="margin: 15px;">Restaurar</button>
		</form>
	</div>

</body>
</html>