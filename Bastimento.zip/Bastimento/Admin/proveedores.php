<?php

session_start();
error_reporting(0);

$validar = $_SESSION['email'];

if( $validar == null || $validar = ''){

  header("Location: ../index.php");
  die();
  
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script src="../js/scrollreveal.min.js"></script>

  	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
  	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

  	<script type="text/javascript" src="../js/jquery.js"></script>

  	<link rel="icon" href="">
	<title>Proovedores</title>
</head>
<style>
	table {
	border-collapse: collapse;
	width: 100%;
	}

	td, th {
		border: 1px solid #dddddd;
		text-aling: left;
		padding: 8px;
	}

	tr:nth-child(even) {
		background-color: #dddddd;
	}

</style>
<body>

	<?php include("../include/navbar-admin.php");?>

	<main style="margin: 25px 0px;">

		<center><h1>Lista de Proveedores</h1></center>
	
		<div class="container" style="background: whitesmoke; border-radius: 3rem; padding: 20px;">
			<center><h3>Proveedores</h3></center>
			<ul>
				<!--Col-1--->
				<li>
					<h2>Compañia 1</h2>
					<table style="background: white;">
						<tr>
							<th>ID</th>
							<th>Deuda</th>
							<th>Estatus</th>
						</tr>
						<tr>
							<td>1</td>
							<td>00,00</td>
							<td>Pagada</td>
						</tr>
						<tr>
							<td>1</td>
							<td>00,00</td>
							<td>Pagada</td>
						</tr>
					</table>
				</li>
				<!--Col-2--->
				<li>
					<h2>Compañia 2</h2>
					<table>
						<tr>
							<th>ID</th>
							<th>Deuda</th>
							<th>Estatus</th>
						</tr>
						<tr>
							<td>2</td>
							<td>-100,00</td>
							<td>Sin pagar</td>
						</tr>
					</table>
				</li>
				<!--Col-3--->
				<li>
					<h2>Compañia 3</h2>
					<table>
						<tr>
							<th>ID</th>
							<th>Deuda</th>
							<th>Estatus</th>
						</tr>
						<tr>
							<td>3</td>
							<td>100,00</td>
							<td>Sin pagar</td>
						</tr>
					</table>
				</li>
			</ul>
		</div>

	</main>

	<?php include("../include/footer.html");?>


	<!--Show-->
	<script>
		$(document).ready(function() {
			$("button").click(function() { 
			$("table").toggle();
		});
	});
	</script>

</body>
</html>