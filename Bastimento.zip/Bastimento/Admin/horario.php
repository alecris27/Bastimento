<?php

session_start();

error_reporting(0);

$validar = $_SESSION['email'];

if( $validar == null || $validar = ''){

  header("Location: ../iniciar.php");
  die();
}

?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-sca">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">

  <!---DataTables-->
    <script type="text/javascript" src="../js/jquery.js"></script>

    <script src="../js/tablaespañol.js"></script>

    <link rel="stylesheet" href="../datatables/css/jquery.dataTables.min.css">

    <script type="text/javascript" src="../datatables/js/jquery.dataTables.min.js"></script>
  <!----->

  <link rel="icon" href="">
  <title>Horario</title>
</head>
<style>
  .container {
    margin: 25px 65px 30px;
  }

  .modal {
    display: none; 
    position: fixed; 
    z-index: 1; 
    padding-top: 100px; 
    left: 0;
    top: 0;
    width: 100%; 
    height: 100%; 
    overflow: auto; 
    background-color: rgb(0,0,0); 
    background-color: rgba(0,0,0,0.4); 
  }

  .modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
  }


  .close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
  }

  .close:hover,
  .close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
  }
</style>
<body>

    <?php include("../include/navbar-admin.php");?>
    
    <div class="container">
      <center><h1>Horario</h1></center>

      <button type="button" class="btn btn-primary" id="myBtn">Marcar Horario</button>
        <div id="myModal" class="modal">
          <!-- Modal content -->
          <div class="modal-content">
            <span class="close">&times;</span>
            <h2><center>Registrar Llegada</center></h2>
            <hr>
            <form action="../include/registrar-horario-admin.php" method="POST">
            
              <div style="margin: 14px 0px 10px 0px; width: 50%;">
                <label>Empleado:</label>
                <select class="form-control" name="empleado">
                  <option value="0">Selecciona el empleado</option>
                  <option value="1"></option>
                </select>
              </div>
              
              <div style="margin: 14px 0px 10px 0px; width: 30%;">
                <label>Fecha de Llegada: </label>
                <input type="datetime-local" class="form-control" name="fecha_llegada" required>
              </div>

              <div style="margin: 14px 0px 10px 0px; width: 30%;">
                <label>Fecha de Salida: </label>
                <input type="datetime-local" class="form-control" name="fecha_salida" required>
              </div>  
                 
              <hr>
              <div>
              <input type="submit" class="btn btn-success" name="registrar" value="Registrar" style="margin: 15px 43%;">
              </div>
            </form>
          </div>
        </div>

        <div style="float: right;">
          <a href="../fpdf/inventario.php" class="btn btn-success">Generar Reporte</a>
        </div>
      <!---Tabla-->
      <div style="margin: 10px; border: ridge;">
        <div class="table-responsive" style="margin: 10px;">
            <table id="example" class="table table-striped table-sm" style="border: ridge;">
              <thead>
                    <tr>
                      <th>Nombre del Empleado</th>
                      <th>Llegada</th>
                      <th>Salida</th>
                      <th>Editar</th>
                    </tr>
              </thead>
                <tbody>
                    <?php
                    $conexion=mysqli_connect("localhost","root","","bastimento");               
                    $SQL="SELECT * FROM horario";
                    $dato = mysqli_query($conexion, $SQL);
                    if($dato -> num_rows >0){
                        while($fila=mysqli_fetch_array($dato)){  
                    ?>
                    <tr>
                      <td><?php echo $fila['empleado']; ?></td>
                      <td><?php echo $fila['llegada']; ?></td>
                      <td><?php echo $fila['salida']; ?></td>
                      <td>
                        <a class="btn btn-success" href="../include/editar_producto.php?id=<?php echo $fila['id']?>" style="margin: 10px;">Editar</a>
                        <a class="btn btn-danger" href="../include/eliminar_producto.php?id=<?php echo $fila['id']?>">Eliminar</a>
                      </td>
                    </tr>
                    <?php
                      }
                    }
                    ?>  
                </tbody>
                  <tfoot>
                  </tfoot>
            </table>
        </div>
      </div>
    </div>
    <?php include("../include/footer.html");?>

    <script type="text/javascript">
      var modal = document.getElementById("myModal");

      // Get the button that opens the modal
      var btn = document.getElementById("myBtn");

      // Get the <span> element that closes the modal
      var span = document.getElementsByClassName("close")[0];

      // When the user clicks the button, open the modal 
      btn.onclick = function() {
        modal.style.display = "block";
      }

      // When the user clicks on <span> (x), close the modal
      span.onclick = function() {
        modal.style.display = "none";
      }

      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
       }
      }
    </script>

</body>
</html>