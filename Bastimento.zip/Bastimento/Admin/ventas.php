<?php

session_start();
error_reporting(0);

$validar = $_SESSION['email'];

if( $validar == null || $validar = ''){

  header("Location: ../index.php");
  die();
  
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <script src="../js/scrollreveal.min.js"></script>

  	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">

  	<!---DataTables-->
	    <script type="text/javascript" src="../js/jquery.js"></script>

	    <script src="../js/tablaespañol.js"></script>

	    <link rel="stylesheet" href="../datatables/css/jquery.dataTables.min.css">

	    <script type="text/javascript" src="../datatables/js/jquery.dataTables.min.js"></script>
  	<!----->

  	<link rel="icon" href="">
	<title>Ventas Diarias</title>
</head>
<style>
  .container {
    margin: 25px 65px 30px;
  }

  .modal {
    display: none; 
    position: fixed; 
    z-index: 1; 
    padding-top: 100px; 
    left: 0;
    top: 0;
    width: 100%; 
    height: 100%; 
    overflow: auto; 
    background-color: rgb(0,0,0); 
    background-color: rgba(0,0,0,0.4); 
  }

  .modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
  }


  .close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
  }

  .close:hover,
  .close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
  }
</style>
<body>

	<?php include("../include/navbar-admin.php");?>

	<div class="container">
      <center><h1>Ventas Diarias</h1></center>

      <button type="button" class="btn btn-primary" id="myBtn">Agregar venta</button>
        <div id="myModal" class="modal">
          <!-- Modal content -->
          <div class="modal-content">
            <span class="close">&times;</span>
            <h2><center>Agregar Venta</center></h2>
            <hr>
            <form action="../include/registrar-mercancia-admi.php" method="POST">
               
              <label>Productos:</label>
              <input class="form-control" type="text" name="productos" required>

              <label>Cantidad:</label>
              <input class="form-control" type="number" name="cantidad" min="0" step="0" max="100"  required>

              <div class="input-group" style="margin: 14px 0px 10px 0px; width: 50%;">
                <label class="label" style="margin: 3px;">Costo:</label>
                <input type="number" class="form-control" id="precio" name="precio" aria-label="Amount (to the nearest dollar)" placeholder="Ingresa el costo ej (2,00 BS)">
                  <div class="input-group-append" style="margin-left: -5px";>
                    <span class="input-group-text">Bs</span>
                  </div>
              </div>

              <label>Fecha</label> 
              <input class="form-control" type="datetime-local" name="fecha_emision" required>
                 
              <hr>
              <div>
              <input type="submit" class="btn btn-success" name="registrar" value="Registrar" style="margin: 15px 43%;">
              </div>
            </form>
          </div>
        </div>

        <div style="float: right;">
          <button onclick="newWindow()" href="../fpdf/ventas.php" class="btn btn-success" >Ver Reporte</button>
         
        </div>
      <!---Tabla-->
      	<div class="table-responsive" style="border: ridge; margin: 15px 0px;padding: 10px;">
            <table id="example" class="table table-striped table-sm" style="border: ridge;">
              <thead>
                <tr>
                  <th>Producto</th>
                  <th>Cantidad</th>
                  <th>Costo</th>
                  <th>Fecha</th>
                  <th>Editar</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $conexion=mysqli_connect("localhost","root","","bastimento");               
                $SQL="SELECT * FROM ventas";
                $dato = mysqli_query($conexion, $SQL);
                if($dato -> num_rows >0){
                    while($fila=mysqli_fetch_array($dato)){  
                ?>
                <tr>
                  <td><?php echo $fila['productos']; ?></td>
                  <td><?php echo $fila['cantidad']; ?></td>
                  <td><?php echo $fila['costo']; ?></td>
                  <td><?php echo $fila['fecha_emision']; ?></td>
                  <td>
                    <a class="btn btn-success" href="../include/editar_producto.php?id=<?php echo $fila['id_venta']?>" style="margin: 10px;">Editar</a>
                    <a class="btn btn-danger" href="../include/eliminar_producto.php?id=<?php echo $fila['id_venta']?>">Eliminar</a>
                  </td>
                </tr>
                <?php
                  }
                }
                ?>  
              </tbody>
              <tfoot>
              </tfoot>
            </table>
          </div>

      </div>
    </div>
    <?php include("../include/footer.html");?>

    <!---Modal--->
    <script type="text/javascript">
      var modal = document.getElementById("myModal");

      // Get the button that opens the modal
      var btn = document.getElementById("myBtn");

      // Get the <span> element that closes the modal
      var span = document.getElementsByClassName("close")[0];

      // When the user clicks the button, open the modal 
      btn.onclick = function() {
        modal.style.display = "block";
      }

      // When the user clicks on <span> (x), close the modal
      span.onclick = function() {
        modal.style.display = "none";
      }

      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
        if (event.target == modal) {
          modal.style.display = "none";
       }
      }
    </script>

    <!--Nueva-Ventana-->
    <script>
      let myWindow;

      function newWindow() {
        myWindow = window.open("inicio.php");
      }
    </script>

</body>
</html>