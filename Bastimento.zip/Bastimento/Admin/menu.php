<?php

session_start();
error_reporting(0);

$validar = $_SESSION['email'];

if( $validar == null || $validar = ''){

  header("Location: ../index.php");
  die();
  
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

    <script src="../js/scrollreveal.min.js"></script>

    <link rel="icon" href="">
    <title>Menu</title>
<style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }
      .bd-mode-toggle {
        z-index: 1500;
      }
</style>

</head>
<body>

  <header data-bs-theme="dark">
      <?php include("../include/navbar-admin.php");  ?>
  </header>

  <main>

      <!--Columna-1
        Empanada A--->
      <div class="album py-5 bg-body-tertiary">
        <div class="Empanadas" style="margin: 0px 50px 0px 50px;">
          <center><h1>Empanadas: Grupo A</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                <img src="../img/jamon-queso.jpg" style="height: 249px;">
                <div class="card-body">
                  <center><h3>Empanada de Jamon y Queso</h3></center>
                  <br>
                  <center><h2>29.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                <img src="../img/domino.jpg">
                <div class="card-body">
                  <center><h3>Empanada de Domino</h3></center>
                  <br>
                  <center><h2>29.00 $</h2></center>
                 </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                <img src="../img/salchicha.jpeg">
                <div class="card-body">
                  <center><h3>Empanada de Salchicha</h3></center>
                  <br>
                  <center><h2>29.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila 2--->
            <!---1--->
            <div class="col" style="margin: 15px 0px 0px 20%;">
              <div class="card shadow-sm">
                <img src="../img/guayanes.jpeg" style="height: 260px;">
                <div class="card-body">
                  <center><h3>Empanada de Guayanes</h3></center>
                    <ul>
                      <li>Maiz</li>
                      <li>Queso</li>
                    </ul>
                  <center><h2>29.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                <img src="../img/queso.jpeg">
                <div class="card-body">
                  <center><h3>Empanada de Queso</h3></center>
                  <br>
                  <center><h2>29.00 $</h2></center>
                 </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--Columna-1-2
        Empanada B--->
      <div class="album py-5 bg-body-tertiary">
        <div class="Empanadas" style="margin: 0px 50px 0px 50px;">
          <center><h1>Empanadas: Grupo B</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                <img src="../img/pabellon.jpg">
                <div class="card-body">
                  <center><h3>Empanada de Pabellon</h3></center>
                  <br>
                  <center><h2>33.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                <img src="../img/mechada.jpg">
                <div class="card-body">
                  <center><h3>Empanada de Mechada</h3></center>
                  <br>
                  <center><h2>33.00 $</h2></center>
                 </div>
              </div>
            </div>

            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                <img src="../img/pollo.jpg">
                <div class="card-body">
                  <center><h3>Empanada de Pollo</h3></center>
                  <br>
                  <center><h2>33.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila 2--->
            <!---1--->
            <div class="col" style="margin: 20px 0px 0px 33%;">
              <div class="card shadow-sm">
                <img src="../img/molida.jpg">
                <div class="card-body">
                  <center><h3>Empanada de Molida</h3></center>
                    <br>
                  <center><h2>33.00 $</h2></center>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--Columna-2
        Combos--->
      <div class="album py-5 bg-body-tertiary">
        <div class="Combos" style="margin: 0px 50px 0px 50px;">
          <center><h1>Combos Empanadas</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Combo 1 Grupo A</h3></center>
                  <ul>
                    <li>2 Empanadas</li>
                    <li>1 Jugo</li>
                  </ul>
                  <center><h2>72.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Combo 2: Grupo A</h3></center>
                  <ul>
                    <li>2 Empanadas</li>
                    <li>1 Café Grande</li>
                  </ul>
                  <center><h2>89.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                   <center><h3>Combo 3: Grupo A</h3></center>
                  <ul>
                    <li>2 Empanadas</li>
                    <li>1 Malta</li>
                  </ul>
                  <center><h2>74.00 $</h2></center>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--Columna-3
        Sandwich--->
      <div class="album py-5 bg-body-tertiary">
        <div class="Sandwich" style="margin: 0px 50px 0px 50px;">
          <center><h1>Sandwich</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Sandwich Light</h3></center>
                  <br>
                  <center><h2>55.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Sandwich Super</h3></center>
                  <br>
                  <center><h2>65.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Sandwich Super especial</h3></center>
                  <br>
                  <center><h2>90.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila 2--->
            <!---1--->
            <div class="col" style="margin: 15px 0px 0px 20%;">
              <div class="card shadow-sm">
                
                <div class="card-body">
                   <center><h3>Sandwich Premium</h3></center>
                  <br>
                  <center><h2>80.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Sandwich Premium Especial</h3></center>
                  <br>
                  <center><h2>115.00 $</h2></center>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--Columna-4
        Pan Submarino--->
      <div class="album py-5 bg-body-tertiary">
        <div class="Pan" style="margin: 0px 50px 0px 50px;">
          <center><h1>Pan Submarino</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Pan Light</h1></center>
                  <br>
                  <center><h2>90.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Pan Super</h1></center>
                  <br>
                  <center><h2>99,00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Pan Super especial</h1></center>
                  <br>
                  <center><h2>135.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila 2--->
            <!---1--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Pan Premium</h1></center>
                  <br>
                  <center><h2>145.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
               
                <div class="card-body">
                  <center><h1>Pan Premium especial</h1></center>
                  <br>
                  <center><h2>180.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
               
                <div class="card-body">
                  <center><h1>Pan Granjero</h1></center>
                  <br>
                  <center><h2>160.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila 3--->
            <!---1--->
            <div class="col" style="margin: 20px 0px 0px 33%;">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Pan de Pernil</h1></center>
                  <br>
                  <center><h2>210.00 $</h2></center>
                </div>
              </div>
            </div>
              
          </div>
        </div>
      </div>
      <!--Columna-5
        Pizza--->
      <div class="album py-5 bg-body-tertiary">
        <div class="Pizza" style="margin: 0px 50px 0px 50px;">
          <center><h1>Mini Pizza</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Pizza Margarita</h3></center>
                  <ul>
                    <li>Salsa Napoli</li>
                    <li>Queso Mozzarella</li>
                  </ul>
                  <center><h2>40.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Pizza Jamón</h3></center>
                  <ul>
                    <li>Salsa Napoli</li>
                    <li>Queso Mozzarella</li>
                    <li>Jamón</li>
                  </ul>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                   <center><h3>Pizza Tropical</h3></center>
                  <ul>
                    <li>Salsa Napoli</li>
                    <li>Queso Mozzarella</li>
                    <li>Jamón</li>
                    <li>Maiz</li>
                  </ul>
                  <center><h2>50.00 $</h2></center>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
      <!--Columna-6
        Especiales--->
      <div class="album py-5 bg-body-tertiary">
        <div class="Especiales" style="margin: 0px 50px 0px 50px;">
          <center><h1>Especiales</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Desayuno Criollo</h3></center>
                  <ul>
                    <li>2 Arepas</li>
                    <li>Queso Blanco</li>
                    <li>Carne Mechada</li>
                    <li>1 Huevo</li>
                  </ul>
                  <center><h2>110.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Pasta</h3></center>
                  <ul>
                    <li>Corta o Larga</li>
                    <li>Salsa Bologna</li>
                    <li>Ragu</li>
                    <li>Napoli</li>
                    <li>Carbonara</li>
                  </ul>
                  <center><h2>110.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Cachitos</h3></center>
                  <ul>
                    <li>Jamón</li>
                    <li>Tocineta</li>
                    <li>Queso</li>
                  </ul>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila 2--->
            <!---1--->
            <div class="col" style="margin: 20px 0px 0px 33%;">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h3>Sopa</h3></center>
                  <br>
                  <center><h2>135.00 $</h2></center>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      <!--Columna-7-
        Bebidas-->
      <div class="album py-5 bg-body-tertiary">
        <div class="Bebidas" style="margin: 0px 50px 0px 50px;">
          <center><h1>Bebidas</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Malta</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Malta Desechable</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Jugo Natural</h1></center>
                  <br>
                  <center><h2>18.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-2--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Jugo Yuki Pack</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Jugo Tetra Natulac</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Refrescos botella 350ml</h1></center>
                  <br>
                  <center><h2>25.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-3--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Bombita Coca-Cola 355ml</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Jugo frica 500ml</h1></center>
                  <br>
                  <center><h2>61.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Jugo del valle 500ml</h1></center>
                  <br>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-4--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Jugo del valle 1,5lt</h1></center>
                  <br>
                  <center><h2>75.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Refrescos lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>55.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Refrescos 1,5lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>74.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-5--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Refrescos 2lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>95.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Refrescos 1,25lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Refrescos GLUP lt</h1></center>
                  <br>
                  <center><h2>25.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-6--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Refrescos GLUP 2lt</h1></center>
                  <br>
                  <center><h2>40.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-7--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Gatorade</h1></center>
                  <br>
                  <center><h2>65.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Ten lipton 500ml</h1></center>
                  <br>
                  <center><h2>60.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3---> 
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Parmalt 500ml</h1></center>
                  <br>
                  <center><h2>60.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-9--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Natulac lt</h1></center>
                  <br>
                  <center><h2>65.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---1--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Yukeri 1,5lt</h1></center>
                  <br>
                  <center><h2>135.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Agua 355ml</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Agua 600ml</h1></center>
                  <br>
                  <center><h2>25.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-10--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Agua 355ml</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---1--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Agua 1,5lt</h1></center>
                  <br>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Café Pequeño</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Café Mediano</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-11--->
            <div class="col" style="margin: 20px 0px 0px 33%;">
              <div class="card shadow-sm">
                
                <div class="card-body">
                  <center><h1>Café Grande</h1></center>
                  <br>
                  <center><h2>50.00 $</h2></center>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      <!--Columna-7--->
      <div class="album py-5 bg-body-tertiary">
        <div class="almuerzos" style="margin: 0px 50px 0px 50px;">
          <center><h1>Bebidas</h1></center>
          <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            <!---Fila-1--->
            <!---1---->    
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Malta</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Malta Desechable</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Jugo Natural</h1></center>
                  <br>
                  <center><h2>18.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-2--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Jugo Yuki Pack</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Jugo Tetra Natulac</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Refrescos botella 350ml</h1></center>
                  <br>
                  <center><h2>25.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-3--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Bombita Coca-Cola 355ml</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Jugo frica 500ml</h1></center>
                  <br>
                  <center><h2>61.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Jugo del valle 500ml</h1></center>
                  <br>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-4--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Jugo del valle 1,5lt</h1></center>
                  <br>
                  <center><h2>75.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Refrescos lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>55.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Refrescos 1,5lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>74.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-5--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Refrescos 2lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>95.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Refrescos 1,25lt</h1></center>
                  <ul>
                    <li>Coca-cola</li>
                    <li>Sabores</li>
                  </ul>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Refrescos GLUP lt</h1></center>
                  <br>
                  <center><h2>25.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-6--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Refrescos GLUP 2lt</h1></center>
                  <br>
                  <center><h2>40.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-7--->
            <!---1----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Gatorade</h1></center>
                  
                  <center><h2>65.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2----> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Ten lipton 500ml</h1></center>
                  <br>
                  <center><h2>60.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3---> 
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Parmalt 500ml</h1></center>
                  <br>
                  <center><h2>60.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-9--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Natulac lt</h1></center>
                  <br>
                  <center><h2>65.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---1--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Yukeri 1,5lt</h1></center>
                  <br>
                  <center><h2>135.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Agua 355ml</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Agua 600ml</h1></center>
                  <br>
                  <center><h2>25.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-10--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Agua 355ml</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---1--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Agua 1,5lt</h1></center>
                  <br>
                  <center><h2>45.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---2--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Café Pequeño</h1></center>
                  <br>
                  <center><h2>20.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---3--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Café Mediano</h1></center>
                  <br>
                  <center><h2>35.00 $</h2></center>
                </div>
              </div>
            </div>
            <!---Fila-11--->
            <div class="col">
              <div class="card shadow-sm">
                <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><title>Placeholder</title><rect width="100%" height="100%" fill="#55595c"/><text x="50%" y="50%" fill="#eceeef" dy=".3em">1</text></svg>
                <div class="card-body">
                  <center><h1>Café Grande</h1></center>
                  <br>
                  <center><h2>50.00 $</h2></center>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

  </main> 

  <?php include("../include/footer.html");  ?>

  <script>
      window.sr = ScrollReveal();
      sr.reveal('.Empanadas', {
      duration: 2000,
      origin: 'bottom',
      distance: '300px'
      });
  </script>

  <script>
      window.sr = ScrollReveal();
      sr.reveal('.Combos', {
      duration: 2000,
      origin: 'bottom',
      distance: '300px'
      });
  </script>

  <script>
      window.sr = ScrollReveal();
      sr.reveal('.Sandwich', {
      duration: 2000,
      origin: 'bottom',
      distance: '300px'
      });
  </script>

  <script>
      window.sr = ScrollReveal();
      sr.reveal('.Pan', {
      duration: 2000,
      origin: 'bottom',
      distance: '300px'
      });
  </script>

  <script>
      window.sr = ScrollReveal();
      sr.reveal('.Pizza', {
      duration: 2000,
      origin: 'bottom',
      distance: '300px'
      });
  </script>

  <script>
      window.sr = ScrollReveal();
      sr.reveal('.Especiales', {
      duration: 2000,
      origin: 'bottom',
      distance: '300px'
      });
  </script>

  <script>
      window.sr = ScrollReveal();
      sr.reveal('.Bebidas', {
      duration: 2000,
      origin: 'bottom',
      distance: '300px'
      });
  </script>

</body>
</html>
